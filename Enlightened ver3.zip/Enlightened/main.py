import pygame 
from pygame import *
import math
import random
from Libraries.game_objects import *

pygame.init() 

window = pygame.display.set_mode((680, 400))
pygame.display.set_caption("Photon Play")


status = True
game_phase = 0 #tittle =0 #ball selection =1 #door selection =2
current_ball = 0
chosen_ball_color = (0,0,0)
current_door = 0
current_ball_2 = 0
    
balls = []
for i in range(0,6):
    balls.append(Ball((100*i+25, 280))) 

doors = []
for i in range(0,5):
    ball = balls[random.randrange(0,6)]
    doors.append(Door((132*i+25, 80), ball.color))
    
doors[random.randrange(0,5)].chosen = True
    
select2 = Selector(25,30, 4)
    
select = Selector(25,230,5)

    
while status:
    for e in pygame.event.get():
            if e.type == pygame.QUIT:
                status = False
            if e.type == pygame.KEYDOWN:
                if game_phase == 0:
                   if e.key == pygame.K_RETURN:
                        game_phase = 1
                     
                elif game_phase == 1:
                    if e.key == pygame.K_RIGHT:
                        select.right(100)
                        current_ball+= (current_ball+1) % 6
                    if e.key == pygame.K_LEFT:
                        select.left(100)
                        current_ball+= (current_ball-1) % 1
                                                
                    if e.key == pygame.K_RETURN:
                        print("ball selected")
                        game_phase = 2 
                        
                elif game_phase == 2:
                        
                    if e.key == pygame.K_LEFT:
                        select2.left(130)
                        current_door+= (current_door -1) % 1
                        
                    if e.key == pygame.K_RIGHT:
                        select2.right(130)
                        current_door+= (current_door +1) % 5
                                  
                    if e.key == pygame.K_RETURN:
                        print("door selected")
                        game_phase = 3

                elif game_phase == 3:
                    if balls[current_ball].color == doors[current_door].color:
                        doors[current_door].state = 1
                        print("increase intensity by pressing enter and door jiggles press enter")
                        if e.key == pygame.K_RETURN:
                            game_phase = 4
                    else: 
                        print("no match try again")
                        if e.key == pygame.K_RETURN:
                            current_ball = 0
                            current_door = 0
                            game_phase = 1
    
                elif game_phase == 4:
                    print("You have picked ball "+balls[current_ball]+"now pick a ball with a higher value")
                    if e.key == pygame.K_RIGHT:
                        select.right(100)
                        current_ball_2 += (current_ball_2+1) % 6
                    if e.key == pygame.K_LEFT:
                        select.left(100)
                        current_ball_2 += (current_ball_2-1) % 1  
                    if e.key == pygame.K_RETURN:
                        print("You have now selected"+balls[current_ball_2]+" !")
                        if balls[1].color == [255,0,0]:
                            balls[1] = 1
                        elif balls[1].color == [128,0,0]:
                            balls[1] = 2
                        elif balls[1].color == [0,255,255]:
                            balls[1] = 3
                        elif balls[1].color == [224,225,255]:
                            balls[1] = 4
                        elif balls[1].color == [0,128,128]:
                            balls[1] = 5
                        elif balls[1].color == [192,192,192]:
                            balls[1] = 6

                        if balls[2].color == [255,0,0]:
                            balls[2] = 1
                        elif balls[2].color == [128,0,0]:
                            balls[2] = 2
                        elif balls[2].color == [0,255,255]:
                            balls[2] = 3
                        elif balls[2].color == [224,225,255]:
                            balls[2] = 4
                        elif balls[2].color == [0,128,128]:
                            balls[2] = 5
                        elif balls[2].color == [192,192,192]:
                            balls[2] = 6
                            
                        if balls[3].color == [255,0,0]:
                            balls[3] = 1
                        elif balls[3].color == [128,0,0]:
                            balls[3] = 2
                        elif balls[3].color == [0,255,255]:
                            balls[3] = 3
                        elif balls[3].color == [224,225,255]:
                            balls[3] = 4
                        elif balls[3].color == [0,128,128]:
                            balls[3] = 5
                        elif balls[3].color == [192,192,192]:
                            balls[3] = 6
                            
                        if balls[4].color == [255,0,0]:
                            balls[4] = 1
                        elif balls[4].color == [128,0,0]:
                            balls[4] = 2
                        elif balls[4].color == [0,255,255]:
                            balls[4] = 3
                        elif balls[4].color == [224,225,255]:
                            balls[4] = 4
                        elif balls[4].color == [0,128,128]:
                            balls[4] = 5
                        elif balls[4].color == [192,192,192]:
                            balls[4] = 6
                            
                        if balls[5].color == [255,0,0]:
                            balls[5] = 1
                        elif balls[5].color == [128,0,0]:
                            balls[5] = 2
                        elif balls[5].color == [0,255,255]:
                            balls[5] = 3
                        elif balls[5].color == [224,225,255]:
                            balls[5] = 4
                        elif balls[5].color == [0,128,128]:
                            balls[5] = 5
                        elif balls[5].color == [192,192,192]:
                            balls[5] = 6
                            
                        if balls[0].color == [255,0,0]:
                            balls[0] = 1
                        elif balls[0].color == [128,0,0]:
                            balls[0] = 2
                        elif balls[0].color == [0,255,255]:
                            balls[0] = 3
                        elif balls[0].color == [224,225,255]:
                            balls[0] = 4
                        elif balls[0].color == [0,128,128]:
                            balls[0] = 5
                        elif balls[0].color == [192,192,192]:
                            balls[0] = 6


                    if balls[current_ball_2] > balls[current_ball]:
                        if e.key == pygame.K_RETURN:
                            print("Good job")
                            game_phase = 5
                        
                elif game_phase == 5:
                    if doors[current_door] == True:
                        print("You selected right door, you may escape!")
                        print("click enter to play again")
                        if e.key == pygame.K_RETURN:
                            game_phase = 1
                            current_ball = 0
                            current_door = 0
                    else:
                        print("You selected wrong door. Try Again.")
                        game_phase = 1
                        current_ball = 0
                        current_door = 0
                    
    if game_phase == 0:
        print("title")
        img = pygame.image.load("Images/title.png").convert()
        img = pygame.transform.scale(img, (640,400))
        window.blit(img, (20,0))
        
    elif game_phase == 1 or game_phase == 2 or game_phase == 3 or game_phase == 4 or game_phase == 5:
        window.fill((255,255,255))
        for item in doors:
            item.draw(window)
        for item in balls:
            item.draw(window)
        if game_phase == 1 or game_phase == 4:
            select.draw(window)
        elif game_phase == 2:
            select2.draw(window)
             


                        
                        
                        
    pygame.display.flip()
    
    