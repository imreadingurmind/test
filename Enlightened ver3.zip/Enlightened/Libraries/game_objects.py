import pygame
import random

#blueprints
class Door(object):
  def __init__(self, position, ballcolor ):
        self.ballcolor: ballcolor
        self.color = ballcolor
        self.size = (100,140)
        self.position = (position)
        self.state = 0 #0 = closed state open = 1 open and enlightened = 2
        self.chosen = False
        self.move = []
        self.current_sprite = 0
  def  draw(self, window):
        rect = pygame.Rect(self.position[0], self.position[1], self.size[0], self.size [1])
        if self.state == 0:
            pass
            pygame.draw.rect(window, (0,0,0), rect)
        elif self.state == 1:
            pygame.draw.rect(window, self.color, rect)
        elif self.state == 2:
            pygame.draw.rect(window, self.color, rect, 4)
        elif self.state == 3:
            pass
      
    
      

             
        
class Ball(object):
    def __init__(self, position):
        piece = ball_color_list[random.randint(0,len(ball_color_list)-1)]
        spaces.append(piece)
        if piece not in used:
            used.append(piece)
            ball_color_list.remove(piece)
            
        self.color = piece  
        self.size = (50,50)
        self.position = (position)
    def  draw(self, window):
        ellipse = pygame.Rect(self.position[0], self.position[1], self.size[0], self.size [1])
        pygame.draw.ellipse(window, self.color, ellipse)
        
class Selector(object):
    def __init__(self, x,y,n):
        self.offset = x
        self.x = x
        self.y = y
        self.n = n
        
    def right(self,dis):
        self.x += dis 
        if self.x > dis*self.n+self.offset:
            self.x = self.offset
            
    def left(self, dis):
        self.x += dis*-1
        if self.x <= self.offset-100:
            self.x = dis*self.n+self.offset
            
    def draw(self,window):
        pygame.draw.polygon(window, (0,0,0), [(self.x, self.y),(self.x+25,self.y+40),(self.x+50,self.y)])
        
ball_color_list = [[255,0,0],[0,255,255],[224,255,255],[128,0,0],[0,128,128],[192,192,192]]

spaces = []

used= []
